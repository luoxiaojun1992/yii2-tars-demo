<?php

namespace app\tars\servant\PHPTest\Yii2Tars\tarsObj;

interface TestTafServiceServant {
	/**
	 * @return int
	 */
	public function test();
}

