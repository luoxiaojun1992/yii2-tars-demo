<?php
return (include __DIR__ . '/../src/config/params.php')['tars']['proto'];
